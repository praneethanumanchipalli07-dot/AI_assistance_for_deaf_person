# AuraAssist IoT gateway

AuraAssist can receive real-time safety events through a WebSocket gateway. The browser connects to the gateway; your ESP32, Raspberry Pi, or other device can publish events to that gateway through Wi-Fi, MQTT, serial, or GPIO.

IoT is optional. If **Optional IoT safety mode** remains off, AuraAssist continues using its normal microphone, camera, captions, visual alerts, and browser vibration features without opening or requiring any IoT port.

## Safety and accuracy controls

The web app lets a user enable or disable four device-agnostic safety areas: fire/smoke/air quality, traffic proximity, entry/home safety, and personal wellbeing/SOS. These preferences are sent to a connected gateway as a `settings` message.

For more accurate non-critical alerts, choose a minimum confidence level and optionally require two supporting sources. Critical fire and SOS signals bypass the second-source check so they are not delayed.

## Connect the web app

1. Run a WebSocket gateway on the same network as the browser.
2. In **Sound Alerts & ML**, enter its address, for example `ws://192.168.1.10:9001`.
3. Select **Connect device**.
4. The status should change to **Connected**.

When testing from an HTTPS deployment, use a secure `wss://` gateway. Local `file://` testing can use `ws://`.

## Event format

Send a JSON message over the WebSocket connection:

```json
{ "type": "event", "event": "fire", "confidence": 0.94 }
```

Supported `event` values:

- `fire`, `smoke`, or `alarm` — opens the emergency screen and sends a fire alert
- `horn` or `vehicle` — sends a vehicle hazard alert
- `doorbell` or `chime` — sends a doorbell alert
- `baby` or `cry` — sends a baby-cry alert
- `hazard` — use a custom message, for example:

```json
{
  "type": "hazard",
  "event": "hazard",
  "severity": "critical",
  "title": "Gas leak detected",
  "message": "Leave the area and contact emergency support."
}
```

The optional `confidence` value must be between `0` and `1`.

## Device architecture

`ESP32 sensors / wearable` → `Wi-Fi or MQTT` → `WebSocket gateway` → `AuraAssist web app`

An ESP32 should generally send sensor readings to a small gateway service rather than connecting straight to the browser. This means the app works even when several sensors are active and keeps hardware credentials off the web page.
